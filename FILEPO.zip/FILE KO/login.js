document.getElementById('myForm').addEventListener('submit', function(e) {
    e.preventDefault();
    window.location.href = 'landing.html';
});